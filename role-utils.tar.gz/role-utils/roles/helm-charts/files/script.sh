#! /bin/bash

C=$(ls  ~/kubeadm-ansible/roles/helm-charts/files/charts/)
for i in  $C
do
helm install $i  ~/kubeadm-ansible/roles/helm-charts/files/charts/$i  -n testing 
done
